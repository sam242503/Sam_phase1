import { hello } from "./main.mjs";

let val = hello();

console.log(val);