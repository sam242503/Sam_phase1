//arrow functions
const addTwoNums = (num1,num2) => num1 + num2;
 
console.log(addTwoNums(1,2));


const sqr = num => num*2;

console.log(sqr(4));